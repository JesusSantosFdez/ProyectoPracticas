export interface MunicipioDiario {
    descripcion: string;
    estado:      number;
    datos:       string;
    metadatos:   string;
}
