export enum PuntoCardinal {
    N = "/assets/viento/norte.png",
    NE = "/assets/viento/noreste.png",
    E = "/assets/viento/brujula.png",
    SE = "/assets/viento/sureste.png",
    S = "/assets/viento/sur.png",
    SO = "/assets/viento/sur-oeste.png",
    O = "/assets/viento/oeste.png",
    NO = "/assets/viento/noroeste.png",
    C = "/assets/viento/calma.png"
  }
  